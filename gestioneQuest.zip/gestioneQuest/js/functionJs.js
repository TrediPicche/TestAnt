function test (selectObject)
{
/*  var myObj = selectObject.value;
    console.log(myObj);
    document.getElementById('changeThis').innerHTML = myObj;

    oppure*/
    document.getElementById('changeThis').innerHTML = "QUESTIONARIO DI " + selectObject.value.toUpperCase();
/*  
    query dal database che stampa tutti i questionari
*/
}